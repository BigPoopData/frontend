                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2004665
DIY Electric longboard (Battery & electronics enclosure) by EmanuelMell is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a enclosure that I use on my DIY electric longboard. It is designed to host two Turnigy 3s 5000mah lipos as well as connectors for charger and a 2x3s to 6s balance connector board and a power switch board and switch. There are no pre drilled holes in the model making it easier to make cut outs and holes where its needed later. 
The part is modeld to fit the radius of a Madrid Weezer 36” longboard.

The five splitted parts are printed one by one on my Wanhao Duplicator i3 V2 at 0.3mm layer hight, 3 perimeters for both the walls and top/bottom. I used PLA for this print.
I then used loctite superglue and friction welding to bond the parts together. 

The hatch part is used as a lid to the cutout in the main piece where the connectors for the charger will sit as well as ability to connect a limo guard. And the pipe part is used to host the cables running to the VESC housing.

# Print Settings

Printer Brand: Wanhao
Printer: Wanhao Duplicator i3 V2
Rafts: No
Supports: Yes
Resolution: 0.3
Infill: 15